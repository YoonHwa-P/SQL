-- PIVOT
-- PIVOT 연산자는 행으로 나열되어 있는 데이터를 열로 나열하여 보기 쉽게 가공함
-- 즉, 세로행을 가로열로 회전시켜 가독성 향상
-- 시즌별 주문 테이블을 생성한다.
DROP TABLE fSeason;

CREATE TABLE fSeason(
    item VARCHAR(20),
    season VARCHAR(20),
    sale INT
);

INSERT INTO fSeason VALUES ('noodle', 'spring', 30);
INSERT INTO fSeason VALUES ('noodle', 'summer', 30);
INSERT INTO fSeason VALUES ('noodle', 'fall', 40);
INSERT INTO fSeason VALUES ('noodle', 'winter', 50);
INSERT INTO fSeason VALUES ('noodle', 'spring', 26);
INSERT INTO fSeason VALUES ('noodle', 'summer', 25);
INSERT INTO fSeason VALUES ('noodle', 'fall', 30);
INSERT INTO fSeason VALUES ('noodle', 'winter', 40);
INSERT INTO fSeason VALUES ('juice', 'spring', 35);
INSERT INTO fSeason VALUES ('juice', 'summer', 50);
INSERT INTO fSeason VALUES ('juice', 'fall', 30);
INSERT INTO fSeason VALUES ('juice', 'winter', 10);
INSERT INTO fSeason VALUES ('juice', 'spring', 30);
INSERT INTO fSeason VALUES ('juice', 'summer', 35);
INSERT INTO fSeason VALUES ('juice', 'fall', 20);
INSERT INTO fSeason VALUES ('juice', 'winter', 15);

commit;

-- 데이터 조회
-- 피봇 집계
SELECT * FROM fSeason;

-- ITEM 별, 봄 여름 가을 겨울  최대값을 구하라
SELECT * FROM fSeason
PIVOT (sale FOR season IN ('spring', 'summer', 'fall', 'winter'));
-- 에러 값 확인
-- ORA-56902: 피벗 작업 내에서는 합계 함수가 필요합니다.
-- sale을 포함시킬 집계함수가 필요하다는 뜻.
-- 아래 함수를 실행해본다.
SELECT * FROM fSeason
PIVOT (MAX(sale) FOR season IN ('spring', 'summer', 'fall', 'winter'));

SELECT * FROM fSeason
PIVOT (MIN(sale) FOR season IN ('spring', 'summer', 'fall', 'winter'));

SELECT * FROM fSeason
PIVOT (SUM(sale) FOR season IN ('spring', 'summer', 'fall', 'winter'));

SELECT * FROM fSeason
PIVOT (AVG(sale) FOR season IN ('spring', 'summer', 'fall', 'winter'));

-- 이번에는 결측값이 있을 경우의 데이터 생성
DROP TABLE fSeason2;

CREATE TABLE fSeason2(
    item VARCHAR(20),
    season VARCHAR(20),
    sale INT
);

INSERT INTO fSeason2 VALUES ('noodle', 'spring', 30);
INSERT INTO fSeason2 VALUES ('noodle', 'summer', 30);
INSERT INTO fSeason2 VALUES ('noodle', 'fall', 40);
INSERT INTO fSeason2 VALUES ('juice', 'summer', 35);
INSERT INTO fSeason2 VALUES ('juice', 'summer', 50);
INSERT INTO fSeason2 VALUES ('juice', 'fall', 30);
INSERT INTO fSeason2 VALUES ('juice', 'winter', 10);

commit;

-- 동일하게 실행해본다.
SELECT * FROM fSeason2;

SELECT * FROM fSeason2
PIVOT (MAX(sale) FOR season IN ('spring', 'summer', 'fall', 'winter'));

SELECT * FROM fSeason2
PIVOT (MIN(sale) FOR season IN ('spring', 'summer', 'fall', 'winter'));

SELECT * FROM fSeason2
PIVOT (SUM(sale) FOR season IN ('spring', 'summer', 'fall', 'winter'));

SELECT * FROM fSeason2
PIVOT (AVG(sale) FOR season IN ('spring', 'summer', 'fall', 'winter'));

-- null값을 0으로 치환
-- 두개를 비교해본다.
SELECT *
FROM fSeason2
PIVOT (SUM(sale) FOR season IN ('spring' as spring,
                                'summer' as summer,
                                'fall' as fall,
                                'winter' as winter));

SELECT item
    , NVL(spring, 0) as spring
    , summer
    , fall
    , NVL(winter, 0) as winter
FROM fSeason2
PIVOT (SUM(sale) FOR season IN ('spring' as spring,
                                'summer' as summer,
                                'fall' as fall,
                                'winter' as winter));

